package com.examly.springapp.exception;

public class PasswordIncorrect extends RuntimeException{
  public PasswordIncorrect(String msg){
    super(msg);

  }
    
}
