package com.examly.springapp.exception;

public class AlreadyAppliedForJobException {

}
