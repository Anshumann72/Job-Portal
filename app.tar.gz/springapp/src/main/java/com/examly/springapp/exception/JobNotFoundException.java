package com.examly.springapp.exception;

public class JobNotFoundException extends RuntimeException{

    public JobNotFoundException(String msg){
        super(msg);

    }
    
}
