export interface Job{
    jobId?:number;
    title:string;
    description:string;
    company:string;
    location:string;
}