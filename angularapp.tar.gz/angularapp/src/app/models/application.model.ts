export interface Application{
    applicationId?:number;
    status?:string;
    yearsOfExperience:number;
    skills:string;
    applicationDate:Date;
    locationPreference:string;
}