
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApplicationService } from 'src/app/services/application.service';

@Component({
  selector: 'app-job-applications',
  templateUrl: './job-applications.component.html',
  styleUrls: ['./job-applications.component.css']
})
export class JobApplicationsComponent implements OnInit {

  applicationForm : FormGroup;

  jobId: number = null;
 
  successMessage = "";
  errormessage = "";

  constructor(private route :ActivatedRoute, private applicationService:ApplicationService ,private router:Router, private fb : FormBuilder) { }

  ngOnInit(): void {
    this.jobId = +this.route.snapshot.paramMap.get('id');
    this.applicationForm = this.fb.group({
      yearsOfExperience : [null],
      skills : [''],
      locationPreference : ['']
    });
  }

  submitApplication(){
  
    this.applicationService.saveApplication(this.applicationForm.value,this.jobId).subscribe((result)=>{
      alert('applied successfully');
      this.router.navigate(['/my-application']);
    },
    (error)=>{
      console.log(error);
      
    })
  }

  

}